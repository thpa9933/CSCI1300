#include <iostream>
using namespace std;


/* part 1
Receiving two inputs from main
Determine if the lengths of those inputs are equal, if they are, enter the while loop
increment through the length of the string, determining if the characters in each string do not equal each other
If this is true, increase count the mismatch
return a float, similarity score (length - mismatch) / length
*/
float similarityScore(string sequence1, string sequence2)
{
    int i = 0;
    float mismatch1 = 0;
    float length = sequence1.length();

    if(sequence1.length() == sequence2.length())
    {
        while(i < length)
        {
            if(sequence1[i] != sequence2[i])
            {
                mismatch1++;
            }
            i++;
        }
            float similarity_score = (length - mismatch1) / length;
            return similarity_score;
    }
    else
        return 0;
}


/* part 2
Receive three inputs from the main function
initialize i = 0, while its less and the length of the genome, the while loop will execute.
create a new variable which is equal to the function similarity score with the given parameters.
use the function .substr to make the genome length the same length of sequence1, otherwise the similarityScore function will never enter the while loop
the similarity score function outputs a percentage, which is then compared the the third parameter, min score.
if the similarityScore percentage is greater or equal to the min_score increase the count.
return count.
*/

int countMatches(string genome, string sequence1, float min_score)
{
    int i = 0;
    int count = 0;


    while(i <= genome.length() - sequence1.length()) // seq1 is subtracted so i does not count pass the genome length
    {
    float results = similarityScore(sequence1, genome.substr(i, sequence1.length()));

        if(results >= min_score)
        {
            count++;
        }
    i++;
    }
    return count;
}

//Part 3
float findBestMatch(string genome, string seq)
{
    int i = 0;
    float best_score = 0;
    float sim_score = 0;

    while(i < genome.length())
    {
    sim_score = similarityScore(seq, genome.substr(i, seq.length()));

        if(sim_score > best_score)
        {
            best_score = sim_score;
        }
    i++;
    }
    return best_score;
}



int findBestGenome(string genome1, string genome2, string genome3, string seq)
{
    float score1 = 0;
    float score2 = 0;
    float score3 = 0;

    score1 = findBestMatch(genome1, seq);
    score2 = findBestMatch(genome2, seq);
    score3 = findBestMatch(genome3, seq);

    if((score1 > score2) && (score1 > score3))
    {
        return 1;
    }
    else if ((score2 > score1) && (score2 > score3))
    {
        return 2;
    }
    else if ((score3 > score1) && (score3 > score2))
    {
        return 3;
    }
    else
    {
        return 0;
    }
}
