#include <iostream>
#include "GameBoard.h"
#include "Destroyer.h"
#include "Invader.h"
#include "Execute.h"
using namespace std;

Execute runThatMug;
int main()
{
    runThatMug.executeThis();
}
